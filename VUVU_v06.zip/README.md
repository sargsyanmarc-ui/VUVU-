# VUVU v0.6

Cette version ajoute une couche plus proche d'une application publiable.

## Nouveau
- Notifications internes pour likes, commentaires et abonnements
- Page Notifications
- Page Paramètres
- Préférences locales avec SharedPreferences
- Demande de suppression de compte
- Blocage utilisateur depuis la recherche
- Limite locale vidéo : 100 Mo
- Limites titre / description
- Brouillon de politique de confidentialité
- Brouillon de conditions d'utilisation
- Checklist Google Play / App Store
- Schéma Supabase mis à jour

## Important
Les notifications de cette version sont des notifications DANS l'application.
Les notifications PUSH Android/iPhone ne sont pas encore activées.

La suppression définitive du compte Auth doit être faite côté serveur
avec une Edge Function ou un backend sécurisé. Ne mettez jamais
la clé Supabase service_role dans l'application mobile.

## Installation
1. Créer le projet Supabase.
2. Exécuter `supabase/schema.sql`.
3. Créer les buckets PUBLIC :
   - videos
   - avatars
4. Mettre URL + clé anon/publishable dans `lib/main.dart`.
5. Créer un projet Flutter :
   flutter create vuvu
6. Remplacer pubspec.yaml et lib/.
7. Exécuter :
   flutter pub get
   flutter run

## Prochaine version v0.7
- notifications push Android/iPhone
- Edge Function sécurisée pour suppression de compte
- vraie modération admin
- compression/transcodage vidéo
- préparation build Android APK/AAB
