# VUVU - Checklist avant Google Play / App Store

## Technique
- Configurer Supabase réel
- Tester création / connexion compte
- Tester upload vidéo Android et iPhone
- Tester vidéo verticale, pause et reprise
- Limiter formats et taille de fichiers
- Ajouter compression / transcodage vidéo
- Gérer réseau lent et reprise d'upload
- Ajouter logs et remontée d'erreurs

## Sécurité / Modération
- Blocage utilisateur
- Signalement contenu
- Modération administrative
- Prévention spam
- Limitation de débit
- Filtrage contenus interdits
- Gestion appels / contestations

## Compte et confidentialité
- Politique de confidentialité publique
- Conditions d'utilisation publiques
- Suppression de compte fonctionnelle
- Export / accès aux données selon besoin
- Consentements et âge minimum
- Informations RGPD

## Stores
- Nom VUVU vérifié juridiquement
- Icône d'application
- Captures d'écran
- Description store
- URL support
- URL confidentialité
- Catégorie et classification d'âge
- Tests internes avant publication
