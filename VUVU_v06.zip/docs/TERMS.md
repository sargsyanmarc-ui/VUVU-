# Conditions d'utilisation - Brouillon VUVU

Dernière mise à jour : à compléter avant publication.

En utilisant VUVU, l'utilisateur accepte de ne pas publier de contenu :
- illégal ;
- violent ou menaçant ;
- haineux ou discriminatoire ;
- exploitant sexuellement des mineurs ;
- portant atteinte aux droits d'autrui ;
- servant au harcèlement, à l'arnaque ou à l'usurpation.

Les utilisateurs peuvent signaler un contenu ou bloquer un compte.
VUVU peut retirer un contenu ou restreindre un compte lorsqu'une violation est constatée.

Avant publication, compléter avec :
- identité de l'éditeur ;
- âge minimum ;
- règles de propriété intellectuelle ;
- modalités de suspension et recours ;
- responsabilité ;
- juridiction applicable ;
- procédure de signalement et traitement.
