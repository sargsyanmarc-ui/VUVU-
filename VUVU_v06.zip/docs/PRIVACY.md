# Politique de confidentialité - Brouillon VUVU

Dernière mise à jour : à compléter avant publication.

VUVU peut traiter les données nécessaires au fonctionnement du service, notamment :
- adresse e-mail et identifiant de compte ;
- nom d'utilisateur, bio et photo de profil ;
- vidéos publiées, commentaires, likes et abonnements ;
- signalements et données nécessaires à la sécurité.

Les finalités principales sont :
- fournir les fonctionnalités du service ;
- sécuriser les comptes ;
- modérer les contenus et traiter les signalements ;
- permettre à l'utilisateur de gérer ou demander la suppression de son compte.

Avant publication, compléter avec :
- identité et coordonnées de l'éditeur ;
- base légale de chaque traitement ;
- durées de conservation ;
- sous-traitants et transferts éventuels ;
- droits RGPD et contact dédié ;
- politique cookies/traceurs si nécessaire ;
- procédure complète de suppression de compte.
