import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final db = Supabase.instance.client;
  List<Map<String, dynamic>> rows = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser!.id;

    final data = await db
        .from('notifications_with_users')
        .select()
        .eq('user_id', uid)
        .order('created_at', ascending: false)
        .limit(100);

    rows = List<Map<String, dynamic>>.from(data);

    await db
        .from('notifications')
        .update({'is_read': true})
        .eq('user_id', uid)
        .eq('is_read', false);

    if (mounted) setState(() => loading = false);
  }

  String label(Map<String, dynamic> n) {
    final actor = '@${n['actor_username'] ?? 'utilisateur'}';
    switch (n['type']) {
      case 'like':
        return '$actor a aimé votre vidéo';
      case 'comment':
        return '$actor a commenté votre vidéo';
      case 'follow':
        return '$actor vous suit maintenant';
      default:
        return 'Nouvelle activité sur VUVU';
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Notifications')),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : rows.isEmpty
            ? const Center(child: Text('Aucune notification.'))
            : ListView.builder(
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final n = rows[i];
                  return ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.notifications),
                    ),
                    title: Text(label(n)),
                    subtitle: Text('${n['created_at'] ?? ''}'),
                  );
                },
              ),
  );
}
