import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool autoplay = true;
  bool privateMode = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      autoplay = prefs.getBool('autoplay') ?? true;
      privateMode = prefs.getBool('private_mode') ?? false;
    });
  }

  Future<void> setAutoplay(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('autoplay', v);
    setState(() => autoplay = v);
  }

  Future<void> setPrivateMode(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('private_mode', v);
    setState(() => privateMode = v);
  }

  Future<void> requestDeleteAccount() async {
    final db = Supabase.instance.client;
    final uid = db.auth.currentUser!.id;

    await db.from('account_deletion_requests').insert({
      'user_id': uid,
      'status': 'pending',
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Demande de suppression enregistrée. '
            'La suppression définitive doit être exécutée côté serveur.',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Paramètres')),
    body: ListView(
      children: [
        SwitchListTile(
          value: autoplay,
          onChanged: setAutoplay,
          title: const Text('Lecture automatique'),
        ),
        SwitchListTile(
          value: privateMode,
          onChanged: setPrivateMode,
          title: const Text('Mode privé'),
          subtitle: const Text('Préférence locale pour la prochaine étape.'),
        ),
        const Divider(),
        const ListTile(
          leading: Icon(Icons.privacy_tip_outlined),
          title: Text('Confidentialité'),
          subtitle: Text('Voir docs/PRIVACY.md dans le projet.'),
        ),
        const ListTile(
          leading: Icon(Icons.description_outlined),
          title: Text('Conditions d’utilisation'),
          subtitle: Text('Voir docs/TERMS.md dans le projet.'),
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
          title: const Text('Demander la suppression du compte'),
          onTap: requestDeleteAccount,
        ),
      ],
    ),
  );
}
