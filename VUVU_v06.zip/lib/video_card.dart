import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoCard extends StatefulWidget {
  const VideoCard({
    super.key,
    required this.url,
    required this.title,
    required this.caption,
    required this.username,
    required this.liked,
    required this.likesCount,
    required this.commentsCount,
    required this.isFollowing,
    required this.onLike,
    required this.onComments,
    required this.onFollow,
    required this.onReport,
  });

  final String url, title, caption, username;
  final bool liked, isFollowing;
  final int likesCount, commentsCount;
  final VoidCallback onLike, onComments, onFollow, onReport;

  @override
  State<VideoCard> createState() => _VideoCardState();
}

class _VideoCardState extends State<VideoCard> {
  late VideoPlayerController controller;
  bool ready = false;

  @override
  void initState() {
    super.initState();
    controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (!mounted) return;
        controller
          ..setLooping(true)
          ..play();
        setState(() => ready = true);
      });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () {
      if (!ready) return;
      setState(() {
        controller.value.isPlaying ? controller.pause() : controller.play();
      });
    },
    child: Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (ready)
          Center(
            child: AspectRatio(
              aspectRatio: controller.value.aspectRatio,
              child: VideoPlayer(controller),
            ),
          )
        else
          const Center(child: CircularProgressIndicator()),
        Positioned(
          left: 16,
          right: 90,
          bottom: 34,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Text('@${widget.username}',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                const SizedBox(width: 10),
                TextButton(
                  onPressed: widget.onFollow,
                  child: Text(
                    widget.isFollowing ? 'Abonné' : 'Suivre',
                    style: TextStyle(
                      color: widget.isFollowing
                          ? Colors.white70
                          : const Color(0xFFFF7A00),
                    ),
                  ),
                ),
              ]),
              Text(widget.title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 5),
              Text(widget.caption, style: const TextStyle(color: Colors.white70)),
            ],
          ),
        ),
        Positioned(
          right: 12,
          bottom: 36,
          child: Column(children: [
            const CircleAvatar(radius: 24, child: Icon(Icons.person)),
            const SizedBox(height: 16),
            IconButton(
              onPressed: widget.onLike,
              icon: Icon(
                Icons.favorite,
                size: 34,
                color: widget.liked ? const Color(0xFFFF2D3D) : Colors.white,
              ),
            ),
            Text('${widget.likesCount}'),
            const SizedBox(height: 10),
            IconButton(
              onPressed: widget.onComments,
              icon: const Icon(Icons.mode_comment_outlined, size: 32),
            ),
            Text('${widget.commentsCount}'),
            const SizedBox(height: 10),
            const Icon(Icons.share, size: 32),
            const SizedBox(height: 16),
            IconButton(
              onPressed: widget.onReport,
              icon: const Icon(Icons.flag_outlined, size: 28),
            ),
          ]),
        ),
      ],
    ),
  );
}
