import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';

class FollowingPage extends StatefulWidget {
  const FollowingPage({super.key});

  @override
  State<FollowingPage> createState() => _FollowingPageState();
}

class _FollowingPageState extends State<FollowingPage> {
  final db = Supabase.instance.client;
  List<Map<String, dynamic>> rows = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser!.id;

    final data = await db
        .from('following_with_profiles')
        .select()
        .eq('follower_id', uid)
        .order('created_at', ascending: false);

    rows = List<Map<String, dynamic>>.from(data);

    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        const Row(children: [
          VuvuLogo(),
          Spacer(),
          Text(
            'Abonnements',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ]),
        const SizedBox(height: 18),
        if (loading)
          const CircularProgressIndicator()
        else if (rows.isEmpty)
          const Expanded(
            child: Center(child: Text('Vous ne suivez encore personne.')),
          )
        else
          Expanded(
            child: ListView.builder(
              itemCount: rows.length,
              itemBuilder: (_, i) {
                final p = rows[i];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: p['avatar_url'] != null
                        ? NetworkImage(p['avatar_url'])
                        : null,
                    child: p['avatar_url'] == null
                        ? const Icon(Icons.person)
                        : null,
                  ),
                  title: Text('@${p['username']}'),
                  subtitle: Text(p['bio'] ?? ''),
                );
              },
            ),
          ),
      ]),
    ),
  );
}
