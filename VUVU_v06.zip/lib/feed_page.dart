import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';
import 'video_card.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  final db = Supabase.instance.client;
  List<Map<String, dynamic>> videos = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser!.id;

    final blocked = await db
        .from('blocks')
        .select('blocked_id')
        .eq('blocker_id', uid);

    final blockedIds = {for (final b in blocked) b['blocked_id']};

    final rows = await db
        .from('videos_with_counts')
        .select()
        .order('created_at', ascending: false);

    final likedRows = await db
        .from('likes')
        .select('video_id')
        .eq('user_id', uid);

    final followRows = await db
        .from('follows')
        .select('following_id')
        .eq('follower_id', uid);

    final likedIds = {for (final r in likedRows) r['video_id']};
    final followingIds = {for (final r in followRows) r['following_id']};

    videos = List<Map<String, dynamic>>.from(rows)
        .where((v) => !blockedIds.contains(v['user_id']))
        .map((v) => {
              ...v,
              'liked': likedIds.contains(v['id']),
              'following': followingIds.contains(v['user_id']),
            })
        .toList();

    if (mounted) setState(() => loading = false);
  }

  Future<void> toggleLike(int i) async {
    final uid = db.auth.currentUser!.id;
    final v = videos[i];

    if (v['liked'] == true) {
      await db.from('likes').delete()
        .eq('user_id', uid)
        .eq('video_id', v['id']);
    } else {
      await db.from('likes').insert({
        'user_id': uid,
        'video_id': v['id'],
      });

      if (v['user_id'] != uid) {
        await db.from('notifications').insert({
          'user_id': v['user_id'],
          'actor_id': uid,
          'type': 'like',
          'video_id': v['id'],
        });
      }
    }

    await load();
  }

  Future<void> toggleFollow(int i) async {
    final uid = db.auth.currentUser!.id;
    final v = videos[i];
    final creator = v['user_id'];

    if (creator == uid) return;

    if (v['following'] == true) {
      await db.from('follows').delete()
        .eq('follower_id', uid)
        .eq('following_id', creator);
    } else {
      await db.from('follows').insert({
        'follower_id': uid,
        'following_id': creator,
      });

      await db.from('notifications').insert({
        'user_id': creator,
        'actor_id': uid,
        'type': 'follow',
      });
    }

    await load();
  }

  Future<void> comments(int i) async {
    final videoId = videos[i]['id'];
    final ownerId = videos[i]['user_id'];
    final input = TextEditingController();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF151515),
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) {
          return FutureBuilder(
            future: db.from('comments_with_users').select()
              .eq('video_id', videoId)
              .order('created_at'),
            builder: (context, snapshot) {
              final rows = snapshot.data == null
                  ? <Map<String, dynamic>>[]
                  : List<Map<String, dynamic>>.from(snapshot.data as List);

              return Padding(
                padding: EdgeInsets.only(
                  left: 16, right: 16, top: 16,
                  bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                ),
                child: SizedBox(
                  height: 430,
                  child: Column(children: [
                    const Text('Commentaires',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    Expanded(
                      child: ListView.builder(
                        itemCount: rows.length,
                        itemBuilder: (_, x) {
                          final c = rows[x];
                          return ListTile(
                            leading: const CircleAvatar(child: Icon(Icons.person)),
                            title: Text('@${c['username'] ?? 'utilisateur'}'),
                            subtitle: Text(c['body'] ?? ''),
                          );
                        },
                      ),
                    ),
                    Row(children: [
                      Expanded(
                        child: TextField(
                          controller: input,
                          decoration: const InputDecoration(
                            hintText: 'Ajouter un commentaire...',
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () async {
                          final body = input.text.trim();
                          if (body.isEmpty) return;

                          final uid = db.auth.currentUser!.id;

                          await db.from('comments').insert({
                            'user_id': uid,
                            'video_id': videoId,
                            'body': body,
                          });

                          if (ownerId != uid) {
                            await db.from('notifications').insert({
                              'user_id': ownerId,
                              'actor_id': uid,
                              'type': 'comment',
                              'video_id': videoId,
                            });
                          }

                          input.clear();
                          setSheetState(() {});
                          await load();
                        },
                        icon: const Icon(Icons.send, color: Color(0xFFFF7A00)),
                      ),
                    ]),
                  ]),
                ),
              );
            },
          );
        },
      ),
    );

    input.dispose();
  }

  Future<void> report(int i) async {
    await db.from('reports').insert({
      'reporter_id': db.auth.currentUser!.id,
      'video_id': videos[i]['id'],
      'reason': 'Signalement utilisateur',
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Signalement envoyé')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : Stack(children: [
            if (videos.isEmpty)
              const Center(child: Text('Aucune vidéo disponible.'))
            else
              PageView.builder(
                scrollDirection: Axis.vertical,
                itemCount: videos.length,
                itemBuilder: (_, i) {
                  final v = videos[i];
                  return VideoCard(
                    url: v['video_url'] ?? '',
                    title: v['title'] ?? 'Vidéo VUVU',
                    caption: v['caption'] ?? '',
                    username: v['username'] ?? 'utilisateur',
                    liked: v['liked'] == true,
                    likesCount: v['likes_count'] ?? 0,
                    commentsCount: v['comments_count'] ?? 0,
                    isFollowing: v['following'] == true,
                    onLike: () => toggleLike(i),
                    onComments: () => comments(i),
                    onFollow: () => toggleFollow(i),
                    onReport: () => report(i),
                  );
                },
              ),
            const SafeArea(
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: VuvuLogo(fontSize: 22),
                ),
              ),
            ),
          ]),
  );
}
