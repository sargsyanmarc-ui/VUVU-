
import 'package:flutter/material.dart';

void main() {
  runApp(const VuvuApp());
}

class VuvuApp extends StatelessWidget {
  const VuvuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VUVU',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        useMaterial3: true,
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  final pages = const [
    VideoFeedScreen(),
    DiscoverScreen(),
    CreateScreen(),
    MessagesScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        height: 64,
        backgroundColor: Colors.black,
        indicatorColor: Colors.white12,
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Découvrir'),
          NavigationDestination(icon: VuvuPlusButton(), label: ''),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

class VuvuPlusButton extends StatelessWidget {
  const VuvuPlusButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 32,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: const Color(0xFFFF6A00), width: 2),
      ),
      child: const Icon(Icons.add, color: Colors.black, size: 24),
    );
  }
}

class VuvuLogo extends StatelessWidget {
  const VuvuLogo({super.key, this.fontSize = 26});
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.play_arrow_rounded, color: const Color(0xFF2196F3), size: fontSize + 5),
        Text('V', style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w900, color: const Color(0xFF2196F3))),
        Text('U', style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w900, color: const Color(0xFFFF2D3D))),
        Text('V', style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w900, color: const Color(0xFF2196F3))),
        Text('U', style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w900, color: const Color(0xFFFF7A00))),
      ],
    );
  }
}

class VideoFeedScreen extends StatelessWidget {
  const VideoFeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Voyage en Normandie', 'La mer, le soleil et un bon moment.', Icons.landscape),
      ('Cuisine rapide', 'Une recette simple en 30 secondes.', Icons.restaurant),
      ('Sport du jour', 'Petit défi pour rester en forme.', Icons.fitness_center),
    ];

    return Stack(
      children: [
        PageView.builder(
          scrollDirection: Axis.vertical,
          itemCount: items.length,
          itemBuilder: (context, i) {
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.blueGrey.shade900,
                    Colors.black,
                    i == 1 ? const Color(0xFF4A1600) : const Color(0xFF071A2A),
                  ],
                ),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Icon(items[i].$3, size: 120, color: Colors.white24),
                  ),
                  Positioned(
                    left: 18,
                    right: 90,
                    bottom: 34,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('@vuvu_creator_${i + 1}',
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(items[i].$1, style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 4),
                        Text(items[i].$2, style: const TextStyle(color: Colors.white70)),
                        const SizedBox(height: 10),
                        const Row(
                          children: [
                            Icon(Icons.music_note, size: 18),
                            SizedBox(width: 5),
                            Text('Son original - VUVU'),
                          ],
                        )
                      ],
                    ),
                  ),
                  const Positioned(
                    right: 14,
                    bottom: 42,
                    child: VideoActions(),
                  ),
                ],
              ),
            );
          },
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: Row(
              children: [
                const VuvuLogo(fontSize: 22),
                const Spacer(),
                TextButton(onPressed: () {}, child: const Text('Pour toi', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                TextButton(onPressed: () {}, child: const Text('Abonnements', style: TextStyle(color: Colors.white70))),
                const Icon(Icons.search),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class VideoActions extends StatelessWidget {
  const VideoActions({super.key});

  @override
  Widget build(BuildContext context) {
    Widget item(IconData icon, String text, {Color? color}) => Padding(
      padding: const EdgeInsets.only(top: 18),
      child: Column(
        children: [
          Icon(icon, size: 34, color: color ?? Colors.white),
          const SizedBox(height: 4),
          Text(text, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );

    return Column(
      children: [
        const CircleAvatar(radius: 24, child: Icon(Icons.person)),
        item(Icons.favorite, '12,4K', color: const Color(0xFFFF2D3D)),
        item(Icons.mode_comment, '342'),
        item(Icons.share, '1,2K'),
      ],
    );
  }
}

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Row(
              children: [
                VuvuLogo(),
                Spacer(),
                Icon(Icons.search),
              ],
            ),
            const SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                hintText: 'Rechercher des vidéos, créateurs...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white10,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 24),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Tendances', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: List.generate(6, (i) => Container(
                  decoration: BoxDecoration(
                    color: Colors.white10,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(child: Text('#tendance${i + 1}')),
                )),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class CreateScreen extends StatelessWidget {
  const CreateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Row(children: [VuvuLogo(), Spacer(), Icon(Icons.settings)]),
          ),
          const Spacer(),
          const Icon(Icons.videocam_outlined, size: 100, color: Colors.white38),
          const SizedBox(height: 20),
          const Text('Crée ta propre histoire', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Text('La caméra et l’import vidéo seront connectés à l’étape suivante.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.all(24),
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFFF2D3D),
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(54),
              ),
              onPressed: () {},
              icon: const Icon(Icons.add),
              label: const Text('Créer une vidéo'),
            ),
          ),
        ],
      ),
    );
  }
}

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const SafeArea(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(children: [VuvuLogo(), Spacer(), Icon(Icons.edit_square)]),
            SizedBox(height: 32),
            ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('VUVU Team'), subtitle: Text('Bienvenue sur VUVU 👋')),
          ],
        ),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Row(children: [VuvuLogo(), Spacer(), Icon(Icons.menu)]),
            const SizedBox(height: 24),
            const CircleAvatar(radius: 46, child: Icon(Icons.person, size: 48)),
            const SizedBox(height: 10),
            const Text('@monprofil', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _Stat('0', 'Abonnements'),
                _Stat('0', 'Abonnés'),
                _Stat('0', "J’aime"),
              ],
            ),
            const SizedBox(height: 18),
            OutlinedButton(onPressed: null, child: Text('Modifier le profil')),
            const Divider(height: 36),
            const Expanded(
              child: Center(
                child: Text('Vos vidéos apparaîtront ici', style: TextStyle(color: Colors.white54)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.number, this.label);
  final String number;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(number, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.white60)),
      ],
    );
  }
}
