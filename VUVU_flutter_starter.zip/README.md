# VUVU — Starter Flutter

Première base réelle de l'application VUVU.

## Inclus
- Fil vertical type Shorts/TikTok avec défilement
- Logo VUVU : bleu / rouge / bleu / orange
- Navigation : Accueil, Découvrir, Créer, Messages, Profil
- Boutons J'aime, Commentaire, Partage
- Écran de création
- Écran profil

## Pour lancer
1. Installer Flutter : https://docs.flutter.dev/get-started/install
2. Créer un nouveau projet Flutter vide :
   flutter create vuvu
3. Remplacer le `pubspec.yaml` et le dossier `lib` par ceux de ce ZIP.
4. Dans le dossier du projet :
   flutter pub get
   flutter run

## Prochaine étape
Connecter :
- Supabase (inscription, profils, abonnements, likes, commentaires)
- stockage vidéo
- upload vidéo
- lecture vidéo réelle
- notifications
- modération
