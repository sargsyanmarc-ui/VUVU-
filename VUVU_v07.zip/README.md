# VUVU v0.7

Cette version rapproche VUVU d'une vraie version bêta.

## Nouveau
- rôle utilisateur / administrateur
- écran de modération administrateur
- masquage d'une vidéo signalée
- classement d'un signalement
- suppression de compte via Edge Function sécurisée
- préparation notifications push
- préparation build Android APK / AAB
- statut vidéo : published / hidden / deleted
- politiques RLS Supabase mises à jour

## Important
Les notifications push ne sont pas encore actives automatiquement.
Le fichier `docs/PUSH_NOTIFICATIONS.md` explique la prochaine étape.

La suppression de compte utilise une Edge Function serveur.
Ne mettez jamais la clé service_role dans l'application Flutter.

## Démarrage
1. Créer le projet Supabase.
2. Exécuter `supabase/schema.sql`.
3. Créer les buckets `videos` et `avatars`.
4. Déployer les fonctions :
   supabase functions deploy delete-account
   supabase functions deploy moderate-report
5. Configurer les secrets Supabase serveur.
6. Ajouter URL + clé anon/publishable dans `lib/main.dart`.
7. Créer le projet Flutter.
8. Remplacer pubspec.yaml + lib/.
9. `flutter pub get`
10. `flutter run`

## Pour créer un administrateur
Dans Supabase, mettre `profiles.role = 'admin'` pour le compte admin choisi.

## Étape suivante v0.8
- notifications push réelles Android
- tokens appareil
- ouverture notification vers vidéo/profil
- meilleure lecture vidéo réelle dans le feed
- compression/transcodage vidéo
- préparation iPhone
