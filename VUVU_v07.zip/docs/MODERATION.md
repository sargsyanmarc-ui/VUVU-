# Modération VUVU v0.7

Flux prévu :
1. Un utilisateur signale une vidéo.
2. Le signalement arrive dans `reports`.
3. Un administrateur avec `profiles.role = 'admin'` voit les signalements.
4. Il peut :
   - classer sans suite ;
   - masquer la vidéo.
5. Les actions sensibles passent par une Edge Function sécurisée.

Avant mise en ligne publique, prévoir aussi :
- règles claires de contenu ;
- délai de traitement ;
- procédure d'appel ;
- traitement spécifique des contenus illégaux ;
- conservation des journaux de modération ;
- outils pour les comptes récidivistes ;
- système anti-spam / anti-abus.
