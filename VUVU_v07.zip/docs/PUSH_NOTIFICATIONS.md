# Notifications push - préparation VUVU v0.7

La v0.7 prépare le modèle de notifications, mais l'envoi push réel nécessite
un fournisseur push.

Architecture recommandée :
1. L'application enregistre un token de notification par appareil.
2. Les tokens sont stockés dans une table device_tokens.
3. Une Edge Function ou un backend envoie une notification lors d'un like,
   commentaire ou abonnement.
4. Les tokens invalides sont supprimés.

À ajouter ensuite :
- Firebase Cloud Messaging pour Android
- APNs via Firebase ou intégration adaptée pour iOS
- gestion permission utilisateur
- ouverture de la bonne vidéo/profil au clic
- désactivation depuis les paramètres
