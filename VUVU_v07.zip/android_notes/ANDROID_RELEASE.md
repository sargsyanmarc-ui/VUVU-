# Préparer Android APK / AAB

## 1. Créer le vrai projet Flutter
flutter create vuvu

## 2. Remplacer les fichiers
- pubspec.yaml
- dossier lib/

## 3. Installer les dépendances
flutter pub get

## 4. Configurer Android
Vérifier dans android/app/build.gradle.kts :
- applicationId unique, par exemple com.vuvu.app
- minSdk compatible avec vos dépendances
- versionCode / versionName cohérents

## 5. Générer une clé de signature
Exemple officiel Flutter/Android :
keytool -genkey -v -keystore ~/vuvu-upload-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias vuvu

Ne partagez jamais le fichier de clé ni son mot de passe.

## 6. Configurer la signature release
Suivre la documentation Flutter Android signing.
Conserver les secrets hors du dépôt Git.

## 7. Tester APK release
flutter build apk --release

## 8. Générer AAB pour Google Play
flutter build appbundle --release

Le fichier sera généralement sous :
build/app/outputs/bundle/release/app-release.aab
