import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';
import 'notifications_page.dart';
import 'settings_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final db = Supabase.instance.client;
  Map<String, dynamic>? profile;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser!.id;
    profile = await db.from('profiles').select().eq('id', uid).maybeSingle();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const VuvuLogo(),
            const Spacer(),
            IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NotificationsPage(),
                  ),
                );
              },
              icon: const Icon(Icons.notifications_outlined),
            ),
            IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const SettingsPage(),
                  ),
                );
              },
              icon: const Icon(Icons.settings_outlined),
            ),
          ],
        ),
        const SizedBox(height: 30),
        const Center(
          child: CircleAvatar(
            radius: 50,
            child: Icon(Icons.person, size: 48),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: Text(
            '@${profile?['username'] ?? 'utilisateur'}',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 6),
        Center(
          child: Text(
            profile?['bio'] ?? '',
            style: const TextStyle(color: Colors.white70),
          ),
        ),
        const SizedBox(height: 20),
        OutlinedButton(
          onPressed: () => db.auth.signOut(),
          child: const Text('Déconnexion'),
        ),
      ],
    ),
  );
}
