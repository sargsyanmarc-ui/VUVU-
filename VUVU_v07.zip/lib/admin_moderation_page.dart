import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AdminModerationPage extends StatefulWidget {
  const AdminModerationPage({super.key});

  @override
  State<AdminModerationPage> createState() => _AdminModerationPageState();
}

class _AdminModerationPageState extends State<AdminModerationPage> {
  final db = Supabase.instance.client;
  List<Map<String, dynamic>> reports = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final rows = await db
        .from('reports_admin_view')
        .select()
        .eq('status', 'open')
        .order('created_at', ascending: true);

    if (mounted) {
      setState(() {
        reports = List<Map<String, dynamic>>.from(rows);
        loading = false;
      });
    }
  }

  Future<void> moderate(Map<String, dynamic> report, String action) async {
    await db.functions.invoke(
      'moderate-report',
      body: {
        'report_id': report['id'],
        'action': action,
      },
    );

    await load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Modération')),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : reports.isEmpty
            ? const Center(child: Text('Aucun signalement ouvert.'))
            : ListView.builder(
                itemCount: reports.length,
                itemBuilder: (_, i) {
                  final r = reports[i];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Vidéo #${r['video_id']}'),
                          Text('Signalé par @${r['reporter_username'] ?? 'utilisateur'}'),
                          Text('Motif : ${r['reason'] ?? ''}'),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            children: [
                              OutlinedButton(
                                onPressed: () => moderate(r, 'dismiss'),
                                child: const Text('Classer sans suite'),
                              ),
                              FilledButton(
                                onPressed: () => moderate(r, 'hide_video'),
                                child: const Text('Masquer la vidéo'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
  );
}
