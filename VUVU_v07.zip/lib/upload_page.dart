import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';

class UploadPage extends StatefulWidget {
  const UploadPage({super.key});

  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  final title = TextEditingController();
  final caption = TextEditingController();
  XFile? file;
  bool busy = false;
  String? status;

  Future<void> choose() async {
    final picked = await ImagePicker().pickVideo(
      source: ImageSource.gallery,
      maxDuration: const Duration(minutes: 3),
    );
    if (picked != null) setState(() => file = picked);
  }

  Future<void> publish() async {
    if (file == null) {
      setState(() => status = 'Choisissez une vidéo.');
      return;
    }

    final bytes = await File(file!.path).length();
    if (bytes > 100 * 1024 * 1024) {
      setState(() => status = 'Vidéo trop lourde : maximum 100 Mo.');
      return;
    }

    setState(() {
      busy = true;
      status = null;
    });

    try {
      final s = Supabase.instance.client;
      final uid = s.auth.currentUser!.id;
      final path = '$uid/${DateTime.now().millisecondsSinceEpoch}.mp4';

      await s.storage.from('videos').upload(
        path,
        File(file!.path),
        fileOptions: const FileOptions(upsert: false, cacheControl: '3600'),
      );

      final url = s.storage.from('videos').getPublicUrl(path);

      await s.from('videos').insert({
        'user_id': uid,
        'title': title.text.trim(),
        'caption': caption.text.trim(),
        'video_url': url,
        'status': 'published',
      });

      title.clear();
      caption.clear();

      setState(() {
        file = null;
        status = 'Vidéo publiée.';
      });
    } catch (e) {
      setState(() => status = 'Erreur : $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Row(
          children: [
            VuvuLogo(),
            Spacer(),
            Text(
              'Créer',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 24),
        OutlinedButton.icon(
          onPressed: busy ? null : choose,
          icon: const Icon(Icons.video_library),
          label: Text(
            file == null ? 'Choisir une vidéo' : 'Vidéo sélectionnée',
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: title,
          maxLength: 80,
          decoration: const InputDecoration(
            labelText: 'Titre',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: caption,
          maxLines: 3,
          maxLength: 500,
          decoration: const InputDecoration(
            labelText: 'Description',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFFFF2D3D),
            minimumSize: const Size.fromHeight(52),
          ),
          onPressed: busy ? null : publish,
          icon: const Icon(Icons.publish),
          label: Text(busy ? 'Envoi...' : 'Publier'),
        ),
        if (status != null)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(status!, textAlign: TextAlign.center),
          ),
      ],
    ),
  );
}
