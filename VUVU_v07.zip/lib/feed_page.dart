import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  final db = Supabase.instance.client;
  List<Map<String, dynamic>> videos = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser!.id;

    final blocked = await db
        .from('blocks')
        .select('blocked_id')
        .eq('blocker_id', uid);

    final blockedIds = {for (final b in blocked) b['blocked_id']};

    final rows = await db
        .from('videos_with_counts')
        .select()
        .eq('status', 'published')
        .order('created_at', ascending: false);

    videos = List<Map<String, dynamic>>.from(rows)
        .where((v) => !blockedIds.contains(v['user_id']))
        .toList();

    if (mounted) setState(() => loading = false);
  }

  Future<void> reportVideo(Map<String, dynamic> video) async {
    final uid = db.auth.currentUser!.id;

    await db.from('reports').insert({
      'reporter_id': uid,
      'video_id': video['id'],
      'reason': 'Signalement utilisateur',
      'status': 'open',
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Signalement envoyé à la modération')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: loading
        ? const Center(child: CircularProgressIndicator())
        : videos.isEmpty
            ? const Center(child: Text('Aucune vidéo disponible.'))
            : PageView.builder(
                scrollDirection: Axis.vertical,
                itemCount: videos.length,
                itemBuilder: (_, i) {
                  final v = videos[i];
                  return Stack(
                    fit: StackFit.expand,
                    children: [
                      Container(
                        color: Colors.black,
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.play_circle_fill,
                          size: 110,
                          color: Colors.white24,
                        ),
                      ),
                      const Positioned(
                        left: 12,
                        top: 12,
                        child: VuvuLogo(fontSize: 22),
                      ),
                      Positioned(
                        left: 16,
                        right: 90,
                        bottom: 32,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '@${v['username'] ?? 'utilisateur'}',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 17,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              v['title'] ?? 'Vidéo VUVU',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              v['caption'] ?? '',
                              style: const TextStyle(color: Colors.white70),
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        right: 12,
                        bottom: 32,
                        child: Column(
                          children: [
                            const CircleAvatar(
                              radius: 24,
                              child: Icon(Icons.person),
                            ),
                            const SizedBox(height: 16),
                            const Icon(Icons.favorite_border, size: 34),
                            Text('${v['likes_count'] ?? 0}'),
                            const SizedBox(height: 12),
                            const Icon(Icons.mode_comment_outlined, size: 32),
                            Text('${v['comments_count'] ?? 0}'),
                            const SizedBox(height: 12),
                            const Icon(Icons.share, size: 32),
                            const SizedBox(height: 12),
                            IconButton(
                              onPressed: () => reportVideo(v),
                              icon: const Icon(Icons.flag_outlined),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
  );
}
