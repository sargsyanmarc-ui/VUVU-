# VUVU v0.8

Cette version améliore la base bêta de VUVU.

## Nouveau
- vraie lecture vidéo plein écran améliorée
- lecture seulement de la vidéo active
- pause automatique des vidéos hors écran
- meilleure gestion d'erreur vidéo
- préparation compression/transcodage
- Firebase Messaging ajouté
- récupération token Android/iPhone
- sauvegarde token appareil dans Supabase
- table `device_tokens`
- Edge Function `send-push`
- documentation Android push
- préparation iPhone / App Store

## Important
Les notifications push sont PRETES côté application pour recevoir un token,
mais l'envoi réel FCM nécessite encore les identifiants Firebase serveur.
Ils ne peuvent pas être intégrés sans vos propres comptes Firebase/Apple.

## Installation rapide
1. Créer Supabase et exécuter `supabase/schema.sql`.
2. Créer buckets `videos` et `avatars`.
3. Configurer URL + clé anon dans `lib/main.dart`.
4. Créer Firebase.
5. Ajouter `google-services.json` pour Android.
6. Ajouter `GoogleService-Info.plist` pour iPhone.
7. Déployer :
   - delete-account
   - moderate-report
   - send-push
8. Lancer Flutter.

## Prochaine version v0.9
- branchement FCM HTTP v1 réel
- deep links vers vidéo/profil
- vrai système likes/commentaires réintégré dans le feed vidéo
- optimisation réseau/cache
- écran onboarding
- préparation bêta testeurs
