# Préparation iPhone / App Store

## Prérequis
- un Mac avec Xcode
- compte Apple Developer
- bundle identifier unique, par exemple com.vuvu.app

## Étapes
1. `flutter create vuvu`
2. remplacer `pubspec.yaml` et `lib/`
3. `flutter pub get`
4. ouvrir `ios/Runner.xcworkspace` dans Xcode
5. choisir Team + Signing
6. ajouter `GoogleService-Info.plist`
7. activer :
   - Push Notifications
   - Background Modes > Remote notifications
8. ajouter les textes de permission nécessaires dans Info.plist
9. tester sur un vrai iPhone
10. générer une archive Xcode
11. envoyer vers App Store Connect

## Avant publication
- politique de confidentialité publique
- suppression de compte fonctionnelle
- captures d'écran iPhone
- icône 1024x1024
- classification d'âge
- formulaire confidentialité App Store
