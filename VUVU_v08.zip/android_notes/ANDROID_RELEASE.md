# Préparation Android VUVU v0.8

## Build
flutter pub get
flutter build apk --release
flutter build appbundle --release

## Firebase
Ajouter `google-services.json` dans `android/app/` après création du projet Firebase.

## Publication
Pour Google Play, utiliser le fichier AAB :
build/app/outputs/bundle/release/app-release.aab

## À vérifier
- applicationId unique
- signature release
- versionCode / versionName
- icône
- politique de confidentialité
- Data safety
- suppression de compte
- captures écran
- classification du contenu
