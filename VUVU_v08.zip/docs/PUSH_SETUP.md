# Notifications push VUVU v0.8

## Ce qui est déjà prêt
- package Firebase Messaging
- demande de permission
- récupération du token appareil
- sauvegarde du token dans Supabase
- table `device_tokens`
- Edge Function `send-push`

## Android
1. Créer un projet Firebase.
2. Ajouter l'application Android VUVU.
3. Télécharger `google-services.json`.
4. Le placer dans `android/app/`.
5. Suivre la configuration FlutterFire/Firebase Android.
6. Tester la récupération du token.

## iPhone
1. Ajouter l'app iOS dans Firebase.
2. Télécharger `GoogleService-Info.plist`.
3. L'ajouter à `ios/Runner` via Xcode.
4. Dans Apple Developer, activer Push Notifications.
5. Configurer APNs dans Firebase.
6. Tester sur un vrai iPhone.

## Envoi réel
L'Edge Function fournie est un squelette.
Pour envoyer réellement par FCM HTTP v1, il faut :
- un compte de service Google côté serveur ;
- générer un token OAuth 2.0 ;
- appeler l'API FCM HTTP v1 ;
- supprimer les tokens devenus invalides.

Ne jamais mettre les secrets Firebase serveur dans l'application Flutter.
