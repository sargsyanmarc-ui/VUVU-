import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_page.dart';
import 'home_shell.dart';
import 'push_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'REMPLACER_PAR_SUPABASE_URL',
    anonKey: 'REMPLACER_PAR_SUPABASE_ANON_KEY',
  );

  // Firebase nécessite les fichiers de configuration Android/iOS.
  // Voir docs/PUSH_SETUP.md.
  try {
    await Firebase.initializeApp();
    await PushService.instance.initialize();
  } catch (_) {
    // Permet de lancer le projet avant la configuration Firebase.
  }

  runApp(const VuvuApp());
}

class VuvuApp extends StatelessWidget {
  const VuvuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VUVU',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: Colors.black,
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Colors.black,
          indicatorColor: Colors.white12,
        ),
      ),
      home: StreamBuilder<AuthState>(
        stream: Supabase.instance.client.auth.onAuthStateChange,
        builder: (context, snapshot) {
          final session = Supabase.instance.client.auth.currentSession;
          return session == null ? const AuthPage() : const HomeShell();
        },
      ),
    );
  }
}
