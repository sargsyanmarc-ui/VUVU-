import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return new Response("Unauthorized", { status: 401 });

    const body = await req.json();
    const reportId = body.report_id;
    const action = body.action;

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return new Response("Unauthorized", { status: 401 });

    const { data: profile } = await userClient
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (!profile || profile.role !== "admin") {
      return new Response("Forbidden", { status: 403 });
    }

    const admin = createClient(supabaseUrl, serviceRole);

    const { data: report } = await admin
      .from("reports")
      .select("id, video_id")
      .eq("id", reportId)
      .single();

    if (!report) return new Response("Report not found", { status: 404 });

    if (action === "dismiss") {
      await admin.from("reports").update({
        status: "dismissed",
        reviewed_at: new Date().toISOString(),
      }).eq("id", reportId);
    } else if (action === "hide_video") {
      await admin.from("videos").update({ status: "hidden" })
        .eq("id", report.video_id);

      await admin.from("reports").update({
        status: "actioned",
        reviewed_at: new Date().toISOString(),
      }).eq("id", reportId);
    } else {
      return new Response("Invalid action", { status: 400 });
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(String(e), { status: 500 });
  }
});
