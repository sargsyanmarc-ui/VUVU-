// Supabase Edge Function: send-push
//
// Préparation FCM HTTP v1.
// Pour une production réelle, configurer un compte de service Google
// côté serveur et générer un access token OAuth 2.0.
// Ne mettez jamais les secrets Firebase dans Flutter.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const userId = body.user_id;
    const title = body.title ?? "VUVU";
    const message = body.message ?? "Nouvelle activité";

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(supabaseUrl, serviceRole);

    const { data: tokens, error } = await admin
      .from("device_tokens")
      .select("token, platform")
      .eq("user_id", userId);

    if (error) {
      return new Response(error.message, { status: 400 });
    }

    // Ici, brancher FCM HTTP v1 avec un token OAuth serveur.
    // Ce squelette confirme les appareils trouvés.
    return new Response(
      JSON.stringify({
        ok: true,
        devices: tokens?.length ?? 0,
        title,
        message,
        note: "FCM HTTP v1 credentials still need server-side configuration"
      }),
      { headers: { "Content-Type": "application/json" } },
    );
  } catch (e) {
    return new Response(String(e), { status: 500 });
  }
});
