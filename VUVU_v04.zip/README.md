# VUVU v0.4

Cette version ajoute les principales fonctions sociales.

## Fonctionnalités
- Création de compte
- Connexion
- Nom utilisateur
- Upload de vraies vidéos
- Lecture vidéo plein écran
- Défilement vertical
- Pause / lecture en touchant la vidéo
- Like / suppression du like
- Compteurs de likes
- Commentaires
- Compteurs de commentaires
- Abonnement / désabonnement à un créateur
- Signalement d'une vidéo
- Base Supabase sécurisée avec RLS
- Logo VUVU bleu / rouge / bleu / orange

## Installation

1. Créez un projet Supabase.
2. Ouvrez SQL Editor.
3. Exécutez `supabase/schema.sql`.
4. Dans Storage, créez un bucket PUBLIC nommé `videos`.
5. Dans `lib/main.dart`, remplacez :
   - `REMPLACER_PAR_SUPABASE_URL`
   - `REMPLACER_PAR_SUPABASE_ANON_KEY`
6. Créez un projet Flutter :
   `flutter create vuvu`
7. Remplacez le `pubspec.yaml` et le dossier `lib`.
8. Lancez :
   `flutter pub get`
   `flutter run`

## Important

Ne mettez jamais la clé `service_role` de Supabase dans l'application.
Utilisez uniquement la clé publique/anon prévue pour le client.

## Prochaine version V0.5
- profils publics complets
- photo de profil
- page "Abonnements"
- recherche utilisateurs / vidéos
- blocage d'un utilisateur
- suppression de ses propres vidéos
- notifications
- meilleure modération
