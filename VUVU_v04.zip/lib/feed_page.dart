import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'upload_page.dart';
import 'video_card.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  final db = Supabase.instance.client;

  List<Map<String, dynamic>> videos = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);

    final uid = db.auth.currentUser!.id;

    final rows = await db
        .from('videos_with_counts')
        .select()
        .order('created_at', ascending: false);

    final likedRows = await db
        .from('likes')
        .select('video_id')
        .eq('user_id', uid);

    final followedRows = await db
        .from('follows')
        .select('following_id')
        .eq('follower_id', uid);

    final likedIds = {
      for (final row in likedRows) row['video_id']
    };

    final followedIds = {
      for (final row in followedRows) row['following_id']
    };

    videos = List<Map<String, dynamic>>.from(rows).map((v) {
      return {
        ...v,
        'liked': likedIds.contains(v['id']),
        'following': followedIds.contains(v['user_id']),
      };
    }).toList();

    if (mounted) {
      setState(() => loading = false);
    }
  }

  Future<void> toggleLike(int index) async {
    final uid = db.auth.currentUser!.id;
    final v = videos[index];
    final videoId = v['id'];
    final liked = v['liked'] == true;

    if (liked) {
      await db
          .from('likes')
          .delete()
          .eq('user_id', uid)
          .eq('video_id', videoId);
    } else {
      await db.from('likes').insert({
        'user_id': uid,
        'video_id': videoId,
      });
    }

    await load();
  }

  Future<void> toggleFollow(int index) async {
    final uid = db.auth.currentUser!.id;
    final v = videos[index];
    final creatorId = v['user_id'];

    if (creatorId == uid) return;

    final following = v['following'] == true;

    if (following) {
      await db
          .from('follows')
          .delete()
          .eq('follower_id', uid)
          .eq('following_id', creatorId);
    } else {
      await db.from('follows').insert({
        'follower_id': uid,
        'following_id': creatorId,
      });
    }

    await load();
  }

  Future<void> showComments(int index) async {
    final videoId = videos[index]['id'];
    final controller = TextEditingController();

    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF151515),
      isScrollControlled: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return FutureBuilder(
              future: db
                  .from('comments_with_users')
                  .select()
                  .eq('video_id', videoId)
                  .order('created_at'),
              builder: (context, snapshot) {
                final rows = snapshot.data == null
                    ? <Map<String, dynamic>>[]
                    : List<Map<String, dynamic>>.from(snapshot.data as List);

                return Padding(
                  padding: EdgeInsets.only(
                    left: 16,
                    right: 16,
                    top: 16,
                    bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                  ),
                  child: SizedBox(
                    height: 430,
                    child: Column(
                      children: [
                        const Text(
                          'Commentaires',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Expanded(
                          child: ListView.builder(
                            itemCount: rows.length,
                            itemBuilder: (_, i) {
                              final c = rows[i];
                              return ListTile(
                                leading: const CircleAvatar(
                                  child: Icon(Icons.person),
                                ),
                                title: Text('@${c['username'] ?? 'utilisateur'}'),
                                subtitle: Text(c['body'] ?? ''),
                              );
                            },
                          ),
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: controller,
                                decoration: const InputDecoration(
                                  hintText: 'Ajouter un commentaire...',
                                ),
                              ),
                            ),
                            IconButton(
                              onPressed: () async {
                                final body = controller.text.trim();
                                if (body.isEmpty) return;

                                await db.from('comments').insert({
                                  'user_id': db.auth.currentUser!.id,
                                  'video_id': videoId,
                                  'body': body,
                                });

                                controller.clear();
                                setSheetState(() {});
                                await load();
                              },
                              icon: const Icon(
                                Icons.send,
                                color: Color(0xFFFF7A00),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );

    controller.dispose();
  }

  Future<void> reportVideo(int index) async {
    final v = videos[index];

    await db.from('reports').insert({
      'reporter_id': db.auth.currentUser!.id,
      'video_id': v['id'],
      'reason': 'Signalement utilisateur',
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Signalement envoyé')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                if (videos.isEmpty)
                  const Center(
                    child: Text('Aucune vidéo publiée pour le moment.'),
                  )
                else
                  PageView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: videos.length,
                    itemBuilder: (_, i) {
                      final v = videos[i];

                      return VideoCard(
                        url: v['video_url'] ?? '',
                        title: v['title'] ?? 'Vidéo VUVU',
                        caption: v['caption'] ?? '',
                        username: v['username'] ?? 'utilisateur',
                        liked: v['liked'] == true,
                        likesCount: v['likes_count'] ?? 0,
                        commentsCount: v['comments_count'] ?? 0,
                        isFollowing: v['following'] == true,
                        onLike: () => toggleLike(i),
                        onComments: () => showComments(i),
                        onFollow: () => toggleFollow(i),
                        onReport: () => reportVideo(i),
                      );
                    },
                  ),

                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    child: Row(
                      children: [
                        const _MiniLogo(),
                        const Spacer(),
                        TextButton(
                          onPressed: () {},
                          child: const Text(
                            'Pour toi',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () {},
                          child: const Text(
                            'Abonnements',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFFFF7A00),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const UploadPage()),
          );
          await load();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _MiniLogo extends StatelessWidget {
  const _MiniLogo();

  @override
  Widget build(BuildContext context) {
    const size = 22.0;

    TextStyle s(Color c) => const TextStyle(
          fontSize: size,
          fontWeight: FontWeight.w900,
        ).copyWith(color: c);

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(
          Icons.play_arrow_rounded,
          color: Color(0xFF2196F3),
        ),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF2D3D))),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF7A00))),
      ],
    );
  }
}
