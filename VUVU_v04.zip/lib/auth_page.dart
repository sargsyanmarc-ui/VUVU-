import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final username = TextEditingController();

  bool create = true;
  bool loading = false;
  String? message;

  Future<void> submit() async {
    setState(() {
      loading = true;
      message = null;
    });

    try {
      final s = Supabase.instance.client;

      if (create) {
        final result = await s.auth.signUp(
          email: email.text.trim(),
          password: password.text,
        );

        final user = result.user;
        if (user != null && username.text.trim().isNotEmpty) {
          await s.from('profiles').upsert({
            'id': user.id,
            'username': username.text.trim(),
          });
        }

        setState(() {
          message = 'Compte créé. Vérifiez votre e-mail si demandé.';
        });
      } else {
        await s.auth.signInWithPassword(
          email: email.text.trim(),
          password: password.text,
        );
      }
    } catch (e) {
      setState(() {
        message = 'Erreur : $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Column(
                children: [
                  const VuvuLogo(fontSize: 44),
                  const SizedBox(height: 12),
                  const Text(
                    'Des vidéos qui vous ressemblent',
                    style: TextStyle(fontSize: 20, color: Colors.white70),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                  if (create) ...[
                    TextField(
                      controller: username,
                      decoration: const InputDecoration(
                        labelText: 'Nom utilisateur',
                        prefixText: '@',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'E-mail',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Mot de passe',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 18),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFFF2D3D),
                      minimumSize: const Size.fromHeight(52),
                    ),
                    onPressed: loading ? null : submit,
                    child: Text(
                      loading
                          ? 'Patientez...'
                          : create
                              ? 'Créer mon compte'
                              : 'Se connecter',
                    ),
                  ),
                  TextButton(
                    onPressed: () => setState(() => create = !create),
                    child: Text(
                      create
                          ? 'J’ai déjà un compte'
                          : 'Créer un nouveau compte',
                    ),
                  ),
                  if (message != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(
                        message!,
                        textAlign: TextAlign.center,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class VuvuLogo extends StatelessWidget {
  const VuvuLogo({super.key, this.fontSize = 30});
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    TextStyle s(Color color) => TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
          color: color,
          height: 1,
        );

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          Icons.play_arrow_rounded,
          color: const Color(0xFF2196F3),
          size: fontSize + 5,
        ),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF2D3D))),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF7A00))),
      ],
    );
  }
}
