# VUVU v0.3 — base connectée

Cette étape prépare VUVU pour de vrais comptes et de vraies vidéos.

## Ajouté
- Supabase Auth : inscription et connexion e-mail/mot de passe
- Base SQL : profils, vidéos, likes, commentaires
- Sélection d'une vidéo depuis le téléphone
- Upload vers Supabase Storage
- Enregistrement de la vidéo dans la base
- Fil vertical alimenté depuis la base
- Déconnexion

## Configuration nécessaire
1. Créer gratuitement un projet Supabase.
2. Ouvrir SQL Editor et exécuter `supabase/schema.sql`.
3. Dans Storage, créer un bucket PUBLIC nommé `videos`.
4. Copier Project URL et anon/publishable key.
5. Les mettre dans `lib/main.dart` à la place de :
   - REMPLACER_PAR_SUPABASE_URL
   - REMPLACER_PAR_SUPABASE_ANON_KEY
6. Créer un projet Flutter puis remplacer les fichiers par ceux-ci.
7. `flutter pub get`
8. `flutter run`

## Sécurité
N'utilisez jamais la clé Supabase `service_role` dans l'application.
Utilisez uniquement la clé client anon/publishable.

## Encore à faire en v0.4
- vrai lecteur vidéo `video_player`
- likes et commentaires réellement reliés aux tables
- profils publics et abonnements
- signalement / blocage / modération
- compression et traitement vidéo
- notifications
