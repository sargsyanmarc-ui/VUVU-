import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'feed_page.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool create = true;
  bool loading = false;
  String? message;

  Future<void> submit() async {
    setState(() { loading = true; message = null; });
    try {
      final s = Supabase.instance.client;
      if (create) {
        await s.auth.signUp(email: email.text.trim(), password: password.text);
        setState(() => message = 'Compte créé. Vérifiez votre e-mail si demandé.');
      } else {
        await s.auth.signInWithPassword(email: email.text.trim(), password: password.text);
        if (mounted) {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const FeedPage()));
        }
      }
    } catch (e) {
      setState(() => message = 'Erreur : $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Column(children: [
              const VuvuLogo(),
              const SizedBox(height: 12),
              Text(create ? 'Créer votre compte' : 'Connexion',
                  style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 24),
              TextField(controller: email, decoration: const InputDecoration(
                labelText: 'E-mail', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: password, obscureText: true, decoration: const InputDecoration(
                labelText: 'Mot de passe', border: OutlineInputBorder())),
              const SizedBox(height: 18),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xffff2d3d),
                  minimumSize: const Size.fromHeight(52)),
                onPressed: loading ? null : submit,
                child: Text(loading ? 'Patientez...' : (create ? 'Créer le compte' : 'Se connecter')),
              ),
              TextButton(
                onPressed: () => setState(() => create = !create),
                child: Text(create ? 'J’ai déjà un compte' : 'Créer un compte'),
              ),
              if (message != null) Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(message!, textAlign: TextAlign.center)),
            ]),
          ),
        ),
      ),
    ),
  );
}

class VuvuLogo extends StatelessWidget {
  const VuvuLogo({super.key});
  @override
  Widget build(BuildContext context) {
    const s = TextStyle(fontSize: 42, fontWeight: FontWeight.w900);
    return const Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.play_arrow_rounded, color: Color(0xff2196f3), size: 48),
      Text('V', style: TextStyle(fontSize:42,fontWeight:FontWeight.w900,color:Color(0xff2196f3))),
      Text('U', style: TextStyle(fontSize:42,fontWeight:FontWeight.w900,color:Color(0xffff2d3d))),
      Text('V', style: TextStyle(fontSize:42,fontWeight:FontWeight.w900,color:Color(0xff2196f3))),
      Text('U', style: TextStyle(fontSize:42,fontWeight:FontWeight.w900,color:Color(0xffff7a00))),
    ]);
  }
}
