import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'upload_page.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});
  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  final db = Supabase.instance.client;
  List<Map<String,dynamic>> videos = [];
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final rows = await db.from('videos').select().order('created_at', ascending: false);
      videos = List<Map<String,dynamic>>.from(rows);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  Future<void> logout() async {
    await db.auth.signOut();
    if (mounted) Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: Colors.black,
      title: const Text('VUVU', style: TextStyle(fontWeight: FontWeight.w900)),
      actions: [
        IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
        IconButton(onPressed: logout, icon: const Icon(Icons.logout)),
      ],
    ),
    body: loading
      ? const Center(child: CircularProgressIndicator())
      : videos.isEmpty
        ? const Center(child: Text('Aucune vidéo. Publiez la première vidéo VUVU.'))
        : PageView.builder(
            scrollDirection: Axis.vertical,
            itemCount: videos.length,
            itemBuilder: (_, i) {
              final v=videos[i];
              return Container(
                color: Colors.black,
                child: Stack(children:[
                  const Center(child: Icon(Icons.play_circle_fill, size:110, color:Colors.white24)),
                  Positioned(left:18,right:80,bottom:35,child:Column(
                    crossAxisAlignment:CrossAxisAlignment.start,
                    children:[
                      Text(v['title'] ?? 'Vidéo VUVU', style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
                      const SizedBox(height:6),
                      Text(v['caption'] ?? '', style:const TextStyle(color:Colors.white70)),
                    ])),
                  const Positioned(right:18,bottom:40,child:Column(children:[
                    Icon(Icons.favorite_border,size:34),SizedBox(height:22),
                    Icon(Icons.mode_comment_outlined,size:32),SizedBox(height:22),
                    Icon(Icons.share,size:32),
                  ]))
                ]),
              );
            }),
    floatingActionButton: FloatingActionButton(
      backgroundColor: const Color(0xffff7a00),
      onPressed: () async {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => const UploadPage()));
        load();
      },
      child: const Icon(Icons.add),
    ),
  );
}
