import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_page.dart';
import 'feed_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'REMPLACER_PAR_SUPABASE_URL',
    anonKey: 'REMPLACER_PAR_SUPABASE_ANON_KEY',
  );
  runApp(const VuvuApp());
}

class VuvuApp extends StatelessWidget {
  const VuvuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VUVU',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: Supabase.instance.client.auth.currentSession == null
          ? const AuthPage()
          : const FeedPage(),
    );
  }
}
