# VUVU v0.5

Cette version ajoute les fonctions prévues après la v0.4.

## Nouveau dans V0.5
- Profil utilisateur plus complet
- Bio
- Photo de profil
- Upload avatar vers Supabase Storage
- Recherche de créateurs
- Page Abonnements
- Blocage utilisateur prévu dans la base
- Suppression de ses propres vidéos
- Table de notifications préparée
- Fil qui masque les créateurs bloqués
- Navigation principale à 5 onglets
- Logo VUVU bleu / rouge / bleu / orange

## Toujours présent
- comptes
- upload vidéo
- lecture plein écran
- défilement vertical
- likes
- commentaires
- abonnements
- signalements

## Installation
1. Créer un projet Supabase.
2. Exécuter `supabase/schema.sql`.
3. Créer 2 buckets PUBLIC dans Storage :
   - videos
   - avatars
4. Mettre votre URL et votre clé anon/publishable dans `lib/main.dart`.
5. Créer le projet Flutter :
   flutter create vuvu
6. Remplacer `pubspec.yaml` et le dossier `lib`.
7. Exécuter :
   flutter pub get
   flutter run

## Important avant publication
Cette version est encore une base de développement. Avant Google Play / App Store, il faudra ajouter :
- conditions d'utilisation
- politique de confidentialité
- suppression de compte
- modération plus complète
- gestion des contenus interdits
- notifications push réelles
- compression/transcodage vidéo
- limitation de taille des fichiers
- journalisation et sécurité supplémentaires
- tests Android et iPhone
