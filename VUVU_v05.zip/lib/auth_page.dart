import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final username = TextEditingController();
  bool create = true;
  bool loading = false;
  String? message;

  Future<void> submit() async {
    setState(() { loading = true; message = null; });

    try {
      final s = Supabase.instance.client;
      if (create) {
        final result = await s.auth.signUp(
          email: email.text.trim(),
          password: password.text,
        );
        if (result.user != null && username.text.trim().isNotEmpty) {
          await s.from('profiles').upsert({
            'id': result.user!.id,
            'username': username.text.trim(),
          });
        }
        setState(() => message = 'Compte créé. Vérifiez votre e-mail si demandé.');
      } else {
        await s.auth.signInWithPassword(
          email: email.text.trim(),
          password: password.text,
        );
      }
    } catch (e) {
      setState(() => message = 'Erreur : $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Column(
              children: [
                const VuvuLogo(fontSize: 44),
                const SizedBox(height: 14),
                const Text('Des vidéos qui vous ressemblent',
                  style: TextStyle(fontSize: 20, color: Colors.white70),
                  textAlign: TextAlign.center),
                const SizedBox(height: 28),
                if (create) ...[
                  TextField(
                    controller: username,
                    decoration: const InputDecoration(
                      labelText: 'Nom utilisateur',
                      prefixText: '@',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                TextField(
                  controller: email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'E-mail',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Mot de passe',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 18),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFFF2D3D),
                    minimumSize: const Size.fromHeight(52),
                  ),
                  onPressed: loading ? null : submit,
                  child: Text(loading
                    ? 'Patientez...'
                    : create ? 'Créer mon compte' : 'Se connecter'),
                ),
                TextButton(
                  onPressed: () => setState(() => create = !create),
                  child: Text(create
                    ? 'J’ai déjà un compte'
                    : 'Créer un nouveau compte'),
                ),
                if (message != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(message!, textAlign: TextAlign.center),
                  ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
