import 'package:flutter/material.dart';

class VuvuLogo extends StatelessWidget {
  const VuvuLogo({super.key, this.fontSize = 28});
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    TextStyle s(Color c) => TextStyle(
      fontSize: fontSize,
      fontWeight: FontWeight.w900,
      color: c,
      height: 1,
    );

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.play_arrow_rounded, color: const Color(0xFF2196F3), size: fontSize + 5),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF2D3D))),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF7A00))),
      ],
    );
  }
}
