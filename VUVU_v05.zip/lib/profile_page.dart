import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final db = Supabase.instance.client;
  Map<String, dynamic>? profile;
  List<Map<String, dynamic>> videos = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser!.id;

    profile = await db.from('profiles').select().eq('id', uid).maybeSingle();

    videos = List<Map<String, dynamic>>.from(
      await db.from('videos').select().eq('user_id', uid).order('created_at', ascending: false)
    );

    if (mounted) setState(() => loading = false);
  }

  Future<void> editProfile() async {
    final username = TextEditingController(text: profile?['username'] ?? '');
    final bio = TextEditingController(text: profile?['bio'] ?? '');

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Modifier le profil'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: username, decoration: const InputDecoration(labelText: 'Nom utilisateur')),
            TextField(controller: bio, maxLines: 3, decoration: const InputDecoration(labelText: 'Bio')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
          FilledButton(
            onPressed: () async {
              await db.from('profiles').update({
                'username': username.text.trim(),
                'bio': bio.text.trim(),
              }).eq('id', db.auth.currentUser!.id);

              if (context.mounted) Navigator.pop(context);
              await load();
            },
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
  }

  Future<void> changeAvatar() async {
    final file = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );
    if (file == null) return;

    final uid = db.auth.currentUser!.id;
    final path = '$uid/avatar.jpg';

    await db.storage.from('avatars').upload(
      path,
      File(file.path),
      fileOptions: const FileOptions(upsert: true, cacheControl: '3600'),
    );

    final url = db.storage.from('avatars').getPublicUrl(path);

    await db.from('profiles').update({
      'avatar_url': url,
    }).eq('id', uid);

    await load();
  }

  Future<void> deleteVideo(Map<String, dynamic> v) async {
    await db.from('videos').delete().eq('id', v['id']);
    await load();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(children: [
              const VuvuLogo(),
              const Spacer(),
              IconButton(
                onPressed: () => db.auth.signOut(),
                icon: const Icon(Icons.logout),
              ),
            ]),
            const SizedBox(height: 22),
            Center(
              child: GestureDetector(
                onTap: changeAvatar,
                child: CircleAvatar(
                  radius: 52,
                  backgroundImage: profile?['avatar_url'] != null
                      ? NetworkImage(profile!['avatar_url'])
                      : null,
                  child: profile?['avatar_url'] == null
                      ? const Icon(Icons.person, size: 52)
                      : null,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: Text('@${profile?['username'] ?? 'utilisateur'}',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 6),
            Center(
              child: Text(profile?['bio'] ?? '',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70)),
            ),
            const SizedBox(height: 14),
            OutlinedButton(
              onPressed: editProfile,
              child: const Text('Modifier le profil'),
            ),
            const Divider(height: 32),
            const Text('Mes vidéos',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            if (videos.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 36),
                child: Center(child: Text('Aucune vidéo publiée.')),
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: videos.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                ),
                itemBuilder: (_, i) {
                  final v = videos[i];
                  return GestureDetector(
                    onLongPress: () => deleteVideo(v),
                    child: Container(
                      color: Colors.white10,
                      child: const Icon(Icons.play_arrow, size: 38),
                    ),
                  );
                },
              ),
            const SizedBox(height: 12),
            const Text(
              'Astuce : appui long sur une de vos vidéos pour la supprimer.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
