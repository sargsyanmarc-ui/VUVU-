# VUVU — Version 0.2

Cette version est un prototype Flutter exécutable sans serveur.

## Fonctionne déjà
- Écran de connexion local
- Logo VUVU bleu / rouge / bleu / orange
- Fil vertical type Shorts/TikTok
- Glisser vers le haut
- Like interactif
- Commentaire avec compteur
- Écran Découvrir
- Écran Créer
- Publication locale d’une nouvelle "vidéo" dans le fil
- Messages de démonstration
- Profil utilisateur
- Déconnexion

## Important
Les données sont encore locales et disparaissent quand l’application redémarre.
La vidéo affichée est encore une maquette graphique, pas un vrai fichier vidéo.

## Pour lancer
1. Installer Flutter.
2. Créer un projet :
   flutter create vuvu
3. Remplacer `pubspec.yaml` et `lib/main.dart` par ceux de ce dossier.
4. Exécuter :
   flutter pub get
   flutter run

## Version 0.3 prévue
- Supabase Auth
- Base de données utilisateurs / vidéos / likes / commentaires
- Upload de vraies vidéos
- Lecture vidéo plein écran
- Abonnements entre utilisateurs
- Signalement / modération
