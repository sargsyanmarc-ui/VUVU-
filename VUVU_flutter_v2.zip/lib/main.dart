
import 'package:flutter/material.dart';

void main() {
  runApp(const VuvuApp());
}

class VuvuApp extends StatefulWidget {
  const VuvuApp({super.key});

  @override
  State<VuvuApp> createState() => _VuvuAppState();
}

class _VuvuAppState extends State<VuvuApp> {
  final store = VuvuStore();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VUVU',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        useMaterial3: true,
      ),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          return store.loggedIn
              ? HomeShell(store: store)
              : AuthScreen(store: store);
        },
      ),
    );
  }
}

class VuvuStore extends ChangeNotifier {
  bool loggedIn = false;
  String username = '';
  String email = '';
  int selectedIndex = 0;

  final List<VuvuVideo> videos = [
    VuvuVideo(
      author: '@manon_travel',
      title: 'Coucher de soleil',
      caption: 'Un moment calme au bord de la mer ✈️',
      likes: 12400,
      comments: 342,
      shares: 1200,
      icon: Icons.wb_sunny_outlined,
      accent: const Color(0xFF173B5E),
    ),
    VuvuVideo(
      author: '@chef_vuvu',
      title: 'Recette express',
      caption: 'Une idée simple en moins de 30 secondes 🍝',
      likes: 8600,
      comments: 221,
      shares: 740,
      icon: Icons.restaurant,
      accent: const Color(0xFF4A1E0F),
    ),
    VuvuVideo(
      author: '@sport_vuvu',
      title: 'Défi du jour',
      caption: '30 secondes pour bouger un peu 💪',
      likes: 9300,
      comments: 188,
      shares: 510,
      icon: Icons.fitness_center,
      accent: const Color(0xFF143B2A),
    ),
  ];

  void login(String name, String mail) {
    username = name.trim().isEmpty ? 'utilisateur' : name.trim();
    email = mail.trim();
    loggedIn = true;
    notifyListeners();
  }

  void logout() {
    loggedIn = false;
    selectedIndex = 0;
    notifyListeners();
  }

  void setTab(int value) {
    selectedIndex = value;
    notifyListeners();
  }

  void toggleLike(int index) {
    final item = videos[index];
    item.liked = !item.liked;
    item.likes += item.liked ? 1 : -1;
    notifyListeners();
  }

  void addComment(int index) {
    videos[index].comments += 1;
    notifyListeners();
  }

  void addMockVideo(String title, String caption) {
    videos.insert(
      0,
      VuvuVideo(
        author: '@$username',
        title: title.trim().isEmpty ? 'Ma nouvelle vidéo' : title.trim(),
        caption: caption.trim().isEmpty ? 'Publié sur VUVU' : caption.trim(),
        likes: 0,
        comments: 0,
        shares: 0,
        icon: Icons.videocam_outlined,
        accent: const Color(0xFF2A163B),
      ),
    );
    selectedIndex = 0;
    notifyListeners();
  }
}

class VuvuVideo {
  VuvuVideo({
    required this.author,
    required this.title,
    required this.caption,
    required this.likes,
    required this.comments,
    required this.shares,
    required this.icon,
    required this.accent,
    this.liked = false,
  });

  final String author;
  final String title;
  final String caption;
  int likes;
  int comments;
  int shares;
  final IconData icon;
  final Color accent;
  bool liked;
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, required this.store});
  final VuvuStore store;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final name = TextEditingController();
  final email = TextEditingController();

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                children: [
                  const VuvuLogo(fontSize: 42),
                  const SizedBox(height: 12),
                  const Text(
                    'Des vidéos qui vous ressemblent',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, color: Colors.white70),
                  ),
                  const SizedBox(height: 36),
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(
                      labelText: 'Nom utilisateur',
                      prefixText: '@',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'E-mail',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFFF2D3D),
                      minimumSize: const Size.fromHeight(54),
                    ),
                    onPressed: () => widget.store.login(name.text, email.text),
                    child: const Text('Entrer dans VUVU'),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Prototype : aucune donnée n’est encore envoyée sur Internet.',
                    style: TextStyle(color: Colors.white54, fontSize: 12),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomeShell extends StatelessWidget {
  const HomeShell({super.key, required this.store});
  final VuvuStore store;

  @override
  Widget build(BuildContext context) {
    final pages = [
      FeedScreen(store: store),
      const DiscoverScreen(),
      CreateScreen(store: store),
      const MessagesScreen(),
      ProfileScreen(store: store),
    ];

    return Scaffold(
      body: pages[store.selectedIndex],
      bottomNavigationBar: NavigationBar(
        height: 64,
        backgroundColor: Colors.black,
        indicatorColor: Colors.white12,
        selectedIndex: store.selectedIndex,
        onDestinationSelected: store.setTab,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Accueil',
          ),
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'Découvrir',
          ),
          NavigationDestination(icon: VuvuPlusButton(), label: ''),
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: 'Messages',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}

class VuvuPlusButton extends StatelessWidget {
  const VuvuPlusButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 32,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: const Color(0xFFFF7A00), width: 2),
      ),
      child: const Icon(Icons.add, color: Colors.black),
    );
  }
}

class VuvuLogo extends StatelessWidget {
  const VuvuLogo({super.key, this.fontSize = 26});
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    TextStyle s(Color c) => TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
          height: 1,
          color: c,
        );

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.play_arrow_rounded,
            color: const Color(0xFF2196F3), size: fontSize + 5),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF2D3D))),
        Text('V', style: s(const Color(0xFF2196F3))),
        Text('U', style: s(const Color(0xFFFF7A00))),
      ],
    );
  }
}

class FeedScreen extends StatelessWidget {
  const FeedScreen({super.key, required this.store});
  final VuvuStore store;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        PageView.builder(
          scrollDirection: Axis.vertical,
          itemCount: store.videos.length,
          itemBuilder: (context, i) {
            final video = store.videos[i];
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [video.accent, Colors.black],
                ),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Icon(video.icon, size: 140, color: Colors.white24),
                  ),
                  Positioned(
                    left: 18,
                    right: 95,
                    bottom: 35,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(video.author,
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(video.title,
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 5),
                        Text(video.caption,
                            style: const TextStyle(color: Colors.white70)),
                        const SizedBox(height: 10),
                        const Row(
                          children: [
                            Icon(Icons.music_note, size: 18),
                            SizedBox(width: 5),
                            Text('Son original - VUVU'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 14,
                    bottom: 42,
                    child: Column(
                      children: [
                        const CircleAvatar(
                            radius: 24, child: Icon(Icons.person)),
                        const SizedBox(height: 18),
                        IconButton(
                          onPressed: () => store.toggleLike(i),
                          icon: Icon(
                            Icons.favorite,
                            size: 34,
                            color: video.liked
                                ? const Color(0xFFFF2D3D)
                                : Colors.white,
                          ),
                        ),
                        Text(_compact(video.likes)),
                        const SizedBox(height: 12),
                        IconButton(
                          onPressed: () => _commentSheet(context, store, i),
                          icon: const Icon(Icons.mode_comment, size: 32),
                        ),
                        Text(_compact(video.comments)),
                        const SizedBox(height: 12),
                        const Icon(Icons.share, size: 32),
                        Text(_compact(video.shares)),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: Row(
              children: [
                const VuvuLogo(fontSize: 22),
                const Spacer(),
                TextButton(
                  onPressed: () {},
                  child: const Text('Pour toi',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                TextButton(
                  onPressed: () {},
                  child: const Text('Abonnements',
                      style: TextStyle(color: Colors.white70)),
                ),
                const Icon(Icons.search),
              ],
            ),
          ),
        ),
      ],
    );
  }

  static String _compact(int value) {
    if (value >= 1000) {
      return '${(value / 1000).toStringAsFixed(value >= 10000 ? 0 : 1)}K';
    }
    return '$value';
  }

  static void _commentSheet(
      BuildContext context, VuvuStore store, int index) {
    final controller = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141414),
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 18,
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  autofocus: true,
                  decoration: const InputDecoration(
                    hintText: 'Ajouter un commentaire...',
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  if (controller.text.trim().isNotEmpty) {
                    store.addComment(index);
                  }
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.send, color: Color(0xFFFF7A00)),
              ),
            ],
          ),
        );
      },
    );
  }
}

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const tags = [
      '#voyage',
      '#humour',
      '#cuisine',
      '#sport',
      '#musique',
      '#france',
      '#animaux',
      '#astuces'
    ];

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Row(children: [
              VuvuLogo(),
              Spacer(),
              Icon(Icons.search),
            ]),
            const SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                hintText: 'Rechercher sur VUVU',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white10,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Tendances',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: GridView.builder(
                itemCount: tags.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.55,
                ),
                itemBuilder: (context, i) => Container(
                  decoration: BoxDecoration(
                    color: Colors.white10,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  alignment: Alignment.center,
                  child: Text(tags[i],
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CreateScreen extends StatefulWidget {
  const CreateScreen({super.key, required this.store});
  final VuvuStore store;

  @override
  State<CreateScreen> createState() => _CreateScreenState();
}

class _CreateScreenState extends State<CreateScreen> {
  final title = TextEditingController();
  final caption = TextEditingController();

  @override
  void dispose() {
    title.dispose();
    caption.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Row(children: [VuvuLogo(), Spacer(), Icon(Icons.settings)]),
          const SizedBox(height: 34),
          Container(
            height: 280,
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white12),
            ),
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.video_library_outlined,
                    size: 72, color: Colors.white54),
                SizedBox(height: 12),
                Text('Sélection vidéo',
                    style:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 7),
                Text(
                  'La sélection d’un vrai fichier vidéo sera ajoutée avec le stockage en ligne.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white54),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: title,
            decoration: const InputDecoration(
              labelText: 'Titre de la vidéo',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: caption,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Description',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFFF2D3D),
              minimumSize: const Size.fromHeight(54),
            ),
            onPressed: () {
              widget.store.addMockVideo(title.text, caption.text);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Vidéo ajoutée au fil VUVU')),
              );
            },
            icon: const Icon(Icons.publish),
            label: const Text('Publier sur VUVU'),
          ),
        ],
      ),
    );
  }
}

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const SafeArea(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(children: [VuvuLogo(), Spacer(), Icon(Icons.edit_square)]),
            SizedBox(height: 24),
            ListTile(
              leading: CircleAvatar(child: Icon(Icons.person)),
              title: Text('VUVU Team'),
              subtitle: Text('Bienvenue sur VUVU 👋'),
            ),
            ListTile(
              leading: CircleAvatar(child: Icon(Icons.person_outline)),
              title: Text('Créateur exemple'),
              subtitle: Text('Merci pour ton abonnement !'),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.store});
  final VuvuStore store;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const VuvuLogo(),
                const Spacer(),
                IconButton(
                  onPressed: store.logout,
                  icon: const Icon(Icons.logout),
                  tooltip: 'Déconnexion',
                ),
              ],
            ),
            const SizedBox(height: 24),
            const CircleAvatar(radius: 46, child: Icon(Icons.person, size: 48)),
            const SizedBox(height: 10),
            Text('@${store.username}',
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            if (store.email.isNotEmpty) ...[
              const SizedBox(height: 5),
              Text(store.email, style: const TextStyle(color: Colors.white54)),
            ],
            const SizedBox(height: 18),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _Stat('0', 'Abonnements'),
                _Stat('0', 'Abonnés'),
                _Stat('0', "J’aime"),
              ],
            ),
            const SizedBox(height: 18),
            OutlinedButton(
              onPressed: () {},
              child: const Text('Modifier le profil'),
            ),
            const Divider(height: 36),
            Expanded(
              child: GridView.builder(
                itemCount: store.videos
                    .where((v) => v.author == '@${store.username}')
                    .length,
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                ),
                itemBuilder: (context, i) => Container(
                  color: Colors.white10,
                  child: const Icon(Icons.play_arrow),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.number, this.label);
  final String number;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(number,
            style: const TextStyle(
                fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.white60)),
      ],
    );
  }
}
