import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';
import 'profile_detail_page.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final db = Supabase.instance.client;
  final query = TextEditingController();
  List<Map<String, dynamic>> results = [];

  Future<void> search() async {
    final q = query.text.trim();
    if (q.isEmpty) return;

    final rows = await db
        .from('profiles')
        .select('id, username, bio, avatar_url')
        .ilike('username', '%$q%')
        .limit(30);

    setState(() => results = List<Map<String, dynamic>>.from(rows));
  }

  Future<void> blockUser(String id) async {
    final uid = db.auth.currentUser!.id;
    if (id == uid) return;

    await db.from('blocks').upsert({
      'blocker_id': uid,
      'blocked_id': id,
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Utilisateur bloqué')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          const Row(
            children: [
              VuvuLogo(),
              Spacer(),
              Text(
                'Recherche',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 18),
          TextField(
            controller: query,
            onSubmitted: (_) => search(),
            decoration: InputDecoration(
              hintText: 'Rechercher un créateur',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                onPressed: search,
                icon: const Icon(Icons.arrow_forward),
              ),
              filled: true,
              fillColor: Colors.white10,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Expanded(
            child: ListView.builder(
              itemCount: results.length,
              itemBuilder: (_, i) {
                final p = results[i];

                return ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ProfileDetailPage(
                          userId: p['id'],
                        ),
                      ),
                    );
                  },
                  leading: CircleAvatar(
                    backgroundImage: p['avatar_url'] != null
                        ? NetworkImage(p['avatar_url'])
                        : null,
                    child: p['avatar_url'] == null
                        ? const Icon(Icons.person)
                        : null,
                  ),
                  title: Text('@${p['username']}'),
                  subtitle: Text(p['bio'] ?? ''),
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'block') blockUser(p['id']);
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(
                        value: 'block',
                        child: Text('Bloquer'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
}
