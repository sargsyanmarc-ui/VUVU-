import 'package:app_links/app_links.dart';
import 'package:flutter/material.dart';
import 'video_detail_page.dart';
import 'profile_detail_page.dart';

class DeepLinkService {
  DeepLinkService._();
  static final instance = DeepLinkService._();

  final AppLinks _appLinks = AppLinks();

  Future<void> initialize(GlobalKey<NavigatorState> navigatorKey) async {
    try {
      final initial = await _appLinks.getInitialLink();
      if (initial != null) {
        _open(initial, navigatorKey);
      }

      _appLinks.uriLinkStream.listen((uri) {
        _open(uri, navigatorKey);
      });
    } catch (_) {}
  }

  void _open(Uri uri, GlobalKey<NavigatorState> navigatorKey) {
    final nav = navigatorKey.currentState;
    if (nav == null) return;

    if (uri.pathSegments.length >= 2 && uri.pathSegments.first == 'video') {
      final id = int.tryParse(uri.pathSegments[1]);
      if (id != null) {
        nav.push(MaterialPageRoute(
          builder: (_) => VideoDetailPage(videoId: id),
        ));
      }
    }

    if (uri.pathSegments.length >= 2 && uri.pathSegments.first == 'profile') {
      final id = uri.pathSegments[1];
      nav.push(MaterialPageRoute(
        builder: (_) => ProfileDetailPage(userId: id),
      ));
    }
  }
}
