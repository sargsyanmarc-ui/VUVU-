import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_page.dart';
import 'home_shell.dart';
import 'push_service.dart';
import 'deep_link_service.dart';

final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'REMPLACER_PAR_SUPABASE_URL',
    anonKey: 'REMPLACER_PAR_SUPABASE_ANON_KEY',
  );

  try {
    await Firebase.initializeApp();
    await PushService.instance.initialize();
  } catch (_) {}

  runApp(const VuvuApp());
}

class VuvuApp extends StatefulWidget {
  const VuvuApp({super.key});

  @override
  State<VuvuApp> createState() => _VuvuAppState();
}

class _VuvuAppState extends State<VuvuApp> {
  @override
  void initState() {
    super.initState();
    DeepLinkService.instance.initialize(navigatorKey);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'VUVU',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: Colors.black,
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Colors.black,
          indicatorColor: Colors.white12,
        ),
      ),
      home: StreamBuilder<AuthState>(
        stream: Supabase.instance.client.auth.onAuthStateChange,
        builder: (context, snapshot) {
          final session = Supabase.instance.client.auth.currentSession;
          return session == null ? const AuthPage() : const HomeShell();
        },
      ),
    );
  }
}
