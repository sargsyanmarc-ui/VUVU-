import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoCard extends StatefulWidget {
  const VideoCard({
    super.key,
    required this.url,
    required this.title,
    required this.caption,
    required this.username,
    required this.active,
    required this.liked,
    required this.likesCount,
    required this.commentsCount,
    required this.onLike,
    required this.onComments,
    required this.onShare,
    required this.onReport,
  });

  final String url, title, caption, username;
  final bool active, liked;
  final int likesCount, commentsCount;
  final VoidCallback onLike, onComments, onShare, onReport;

  @override
  State<VideoCard> createState() => _VideoCardState();
}

class _VideoCardState extends State<VideoCard> {
  VideoPlayerController? controller;
  bool ready = false;
  bool failed = false;

  @override
  void initState() {
    super.initState();
    initialize();
  }

  Future<void> initialize() async {
    try {
      controller = VideoPlayerController.networkUrl(Uri.parse(widget.url));
      await controller!.initialize();
      await controller!.setLooping(true);

      if (widget.active) {
        await controller!.play();
      }

      if (mounted) {
        setState(() => ready = true);
      }
    } catch (_) {
      if (mounted) setState(() => failed = true);
    }
  }

  @override
  void didUpdateWidget(covariant VideoCard oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (controller == null || !ready) return;

    if (widget.active && !oldWidget.active) {
      controller!.play();
    } else if (!widget.active && oldWidget.active) {
      controller!.pause();
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () {
      if (!ready || controller == null) return;
      setState(() {
        controller!.value.isPlaying
            ? controller!.pause()
            : controller!.play();
      });
    },
    child: Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),

        if (failed)
          const Center(child: Text('Impossible de lire cette vidéo.'))
        else if (!ready || controller == null)
          const Center(child: CircularProgressIndicator())
        else
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: controller!.value.size.width,
              height: controller!.value.size.height,
              child: VideoPlayer(controller!),
            ),
          ),

        Positioned(
          left: 16,
          right: 95,
          bottom: 34,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '@${widget.username}',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 17,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                widget.caption,
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ),

        Positioned(
          right: 12,
          bottom: 34,
          child: Column(
            children: [
              const CircleAvatar(
                radius: 24,
                child: Icon(Icons.person),
              ),
              const SizedBox(height: 14),

              IconButton(
                onPressed: widget.onLike,
                icon: Icon(
                  Icons.favorite,
                  size: 34,
                  color: widget.liked
                      ? const Color(0xFFFF2D3D)
                      : Colors.white,
                ),
              ),
              Text('${widget.likesCount}'),

              const SizedBox(height: 10),

              IconButton(
                onPressed: widget.onComments,
                icon: const Icon(
                  Icons.mode_comment_outlined,
                  size: 32,
                ),
              ),
              Text('${widget.commentsCount}'),

              const SizedBox(height: 10),

              IconButton(
                onPressed: widget.onShare,
                icon: const Icon(Icons.share, size: 32),
              ),

              const SizedBox(height: 10),

              IconButton(
                onPressed: widget.onReport,
                icon: const Icon(Icons.flag_outlined),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}
