import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'video_card.dart';

class VideoDetailPage extends StatefulWidget {
  const VideoDetailPage({
    super.key,
    required this.videoId,
  });

  final int videoId;

  @override
  State<VideoDetailPage> createState() => _VideoDetailPageState();
}

class _VideoDetailPageState extends State<VideoDetailPage> {
  final db = Supabase.instance.client;
  Map<String, dynamic>? video;
  bool liked = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser?.id;

    final row = await db.from('videos_with_counts')
        .select()
        .eq('id', widget.videoId)
        .maybeSingle();

    if (uid != null) {
      final l = await db.from('likes')
          .select('video_id')
          .eq('user_id', uid)
          .eq('video_id', widget.videoId)
          .maybeSingle();

      liked = l != null;
    }

    if (mounted) {
      setState(() => video = row);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (video == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final v = video!;

    return Scaffold(
      appBar: AppBar(title: const Text('Vidéo VUVU')),
      body: VideoCard(
        url: v['video_url'] ?? '',
        title: v['title'] ?? '',
        caption: v['caption'] ?? '',
        username: v['username'] ?? 'utilisateur',
        active: true,
        liked: liked,
        likesCount: v['likes_count'] ?? 0,
        commentsCount: v['comments_count'] ?? 0,
        onLike: () {},
        onComments: () {},
        onShare: () {},
        onReport: () {},
      ),
    );
  }
}
