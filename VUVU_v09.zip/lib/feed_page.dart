import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'logo.dart';
import 'video_card.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  final db = Supabase.instance.client;

  List<Map<String, dynamic>> videos = [];
  Set<int> likedIds = {};
  bool loading = true;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final uid = db.auth.currentUser!.id;

    final blocked = await db
        .from('blocks')
        .select('blocked_id')
        .eq('blocker_id', uid);

    final blockedIds = {for (final b in blocked) b['blocked_id']};

    final rows = await db
        .from('videos_with_counts')
        .select()
        .eq('status', 'published')
        .order('created_at', ascending: false);

    final likes = await db
        .from('likes')
        .select('video_id')
        .eq('user_id', uid);

    likedIds = {
      for (final item in likes) item['video_id'] as int
    };

    videos = List<Map<String, dynamic>>.from(rows)
        .where((v) => !blockedIds.contains(v['user_id']))
        .toList();

    if (mounted) setState(() => loading = false);
  }

  Future<void> toggleLike(Map<String, dynamic> video) async {
    final uid = db.auth.currentUser!.id;
    final id = video['id'] as int;

    if (likedIds.contains(id)) {
      await db.from('likes')
          .delete()
          .eq('user_id', uid)
          .eq('video_id', id);
    } else {
      await db.from('likes').insert({
        'user_id': uid,
        'video_id': id,
      });

      if (video['user_id'] != uid) {
        await db.from('notifications').insert({
          'user_id': video['user_id'],
          'actor_id': uid,
          'type': 'like',
          'video_id': id,
        });
      }
    }

    await load();
  }

  Future<void> openComments(Map<String, dynamic> video) async {
    final controller = TextEditingController();
    final videoId = video['id'];
    final ownerId = video['user_id'];

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF151515),
      builder: (context) => StatefulBuilder(
        builder: (context, refreshSheet) {
          return FutureBuilder(
            future: db.from('comments_with_users')
                .select()
                .eq('video_id', videoId)
                .order('created_at'),
            builder: (context, snapshot) {
              final comments = snapshot.data == null
                  ? <Map<String, dynamic>>[]
                  : List<Map<String, dynamic>>.from(snapshot.data as List);

              return Padding(
                padding: EdgeInsets.only(
                  left: 16,
                  right: 16,
                  top: 16,
                  bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                ),
                child: SizedBox(
                  height: 450,
                  child: Column(
                    children: [
                      const Text(
                        'Commentaires',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: ListView.builder(
                          itemCount: comments.length,
                          itemBuilder: (_, i) {
                            final c = comments[i];
                            return ListTile(
                              leading: const CircleAvatar(
                                child: Icon(Icons.person),
                              ),
                              title: Text(
                                '@${c['username'] ?? 'utilisateur'}',
                              ),
                              subtitle: Text(c['body'] ?? ''),
                            );
                          },
                        ),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: controller,
                              decoration: const InputDecoration(
                                hintText: 'Ajouter un commentaire...',
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () async {
                              final text = controller.text.trim();
                              if (text.isEmpty) return;

                              final uid = db.auth.currentUser!.id;

                              await db.from('comments').insert({
                                'user_id': uid,
                                'video_id': videoId,
                                'body': text,
                              });

                              if (ownerId != uid) {
                                await db.from('notifications').insert({
                                  'user_id': ownerId,
                                  'actor_id': uid,
                                  'type': 'comment',
                                  'video_id': videoId,
                                });
                              }

                              controller.clear();
                              refreshSheet(() {});
                              await load();
                            },
                            icon: const Icon(
                              Icons.send,
                              color: Color(0xFFFF7A00),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );

    controller.dispose();
  }

  Future<void> shareVideo(Map<String, dynamic> video) async {
    final link = 'https://vuvu.app/video/${video['id']}';

    await Clipboard.setData(
      ClipboardData(text: link),
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Lien VUVU copié'),
        ),
      );
    }
  }

  Future<void> reportVideo(Map<String, dynamic> video) async {
    final uid = db.auth.currentUser!.id;

    await db.from('reports').insert({
      'reporter_id': uid,
      'video_id': video['id'],
      'reason': 'Signalement utilisateur',
      'status': 'open',
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Signalement envoyé à la modération'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: loading
        ? const Center(child: CircularProgressIndicator())
        : videos.isEmpty
            ? const Center(
                child: Text('Aucune vidéo disponible.'),
              )
            : PageView.builder(
                scrollDirection: Axis.vertical,
                itemCount: videos.length,
                onPageChanged: (i) {
                  setState(() => currentIndex = i);
                },
                itemBuilder: (_, i) {
                  final v = videos[i];

                  return Stack(
                    fit: StackFit.expand,
                    children: [
                      VideoCard(
                        url: v['video_url'] ?? '',
                        title: v['title'] ?? 'Vidéo VUVU',
                        caption: v['caption'] ?? '',
                        username: v['username'] ?? 'utilisateur',
                        active: i == currentIndex,
                        liked: likedIds.contains(v['id']),
                        likesCount: v['likes_count'] ?? 0,
                        commentsCount: v['comments_count'] ?? 0,
                        onLike: () => toggleLike(v),
                        onComments: () => openComments(v),
                        onShare: () => shareVideo(v),
                        onReport: () => reportVideo(v),
                      ),

                      const Positioned(
                        left: 12,
                        top: 12,
                        child: VuvuLogo(fontSize: 22),
                      ),
                    ],
                  );
                },
              ),
  );
}
