import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'admin_moderation_page.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final db = Supabase.instance.client;
  bool autoplay = true;
  bool privateMode = false;
  bool admin = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final uid = db.auth.currentUser!.id;
    final profile = await db
        .from('profiles')
        .select('role')
        .eq('id', uid)
        .maybeSingle();

    if (!mounted) return;

    setState(() {
      autoplay = prefs.getBool('autoplay') ?? true;
      privateMode = prefs.getBool('private_mode') ?? false;
      admin = profile?['role'] == 'admin';
    });
  }

  Future<void> setAutoplay(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('autoplay', v);
    setState(() => autoplay = v);
  }

  Future<void> setPrivateMode(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('private_mode', v);
    setState(() => privateMode = v);
  }

  Future<void> deleteAccount() async {
    try {
      await db.functions.invoke('delete-account');
      await db.auth.signOut();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Suppression impossible : $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Paramètres')),
    body: ListView(
      children: [
        SwitchListTile(
          value: autoplay,
          onChanged: setAutoplay,
          title: const Text('Lecture automatique'),
        ),
        SwitchListTile(
          value: privateMode,
          onChanged: setPrivateMode,
          title: const Text('Mode privé'),
        ),
        if (admin)
          ListTile(
            leading: const Icon(Icons.admin_panel_settings),
            title: const Text('Modération administrateur'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AdminModerationPage(),
                ),
              );
            },
          ),
        const Divider(),
        ListTile(
          leading: const Icon(
            Icons.delete_forever,
            color: Colors.redAccent,
          ),
          title: const Text('Supprimer définitivement mon compte'),
          subtitle: const Text('Action irréversible'),
          onTap: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Supprimer le compte ?'),
                content: const Text(
                  'Votre compte et vos données associées seront supprimés définitivement.',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Annuler'),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Supprimer'),
                  ),
                ],
              ),
            );

            if (ok == true) {
              await deleteAccount();
            }
          },
        ),
      ],
    ),
  );
}
