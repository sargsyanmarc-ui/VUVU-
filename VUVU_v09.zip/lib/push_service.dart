import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PushService {
  PushService._();
  static final instance = PushService._();

  final messaging = FirebaseMessaging.instance;
  final supabase = Supabase.instance.client;

  Future<void> initialize() async {
    await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    final token = await messaging.getToken();
    if (token != null) {
      await saveToken(token);
    }

    FirebaseMessaging.instance.onTokenRefresh.listen(saveToken);
  }

  Future<void> saveToken(String token) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    await supabase.from('device_tokens').upsert({
      'user_id': user.id,
      'token': token,
      'platform': Platform.isIOS ? 'ios' : 'android',
      'updated_at': DateTime.now().toIso8601String(),
    }, onConflict: 'token');
  }
}
