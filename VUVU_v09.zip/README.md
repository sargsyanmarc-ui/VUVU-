# VUVU v0.9

Cette version continue la préparation de la bêta.

## Nouveau
- likes réintégrés dans le vrai fil vidéo
- commentaires réintégrés
- partage d'un lien vidéo
- liens profonds / deep links
- ouverture directe d'une vidéo
- ouverture directe d'un profil
- notifications internes cliquables
- préparation push avec deep link
- page détail vidéo
- page détail profil
- checklist bêta testeurs

## Ce qui nécessite encore vos comptes
Certaines fonctions ne peuvent pas être finalisées sans :
- projet Supabase réel
- projet Firebase réel
- domaine pour les deep links
- compte Apple Developer pour iPhone

## Installation
1. Exécuter `supabase/schema.sql`.
2. Créer les buckets `videos` et `avatars`.
3. Configurer Supabase dans `lib/main.dart`.
4. Configurer Firebase Android/iOS.
5. Déployer les Edge Functions.
6. Créer le projet Flutter.
7. Copier les fichiers.
8. `flutter pub get`
9. `flutter run`

## Prochaine étape v1.0 bêta
- configuration réelle avec vos clés
- icône application finale
- écran onboarding
- pages légales intégrées dans l'app
- builds Android / iPhone testables
- correction finale des erreurs avant publication
