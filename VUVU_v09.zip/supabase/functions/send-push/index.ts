import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const body = await req.json();

    const userId = body.user_id;
    const title = body.title ?? "VUVU";
    const message = body.message ?? "Nouvelle activité";
    const deeplink = body.deeplink ?? null;

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const admin = createClient(supabaseUrl, serviceRole);

    const { data: tokens, error } = await admin
      .from("device_tokens")
      .select("token, platform")
      .eq("user_id", userId);

    if (error) {
      return new Response(error.message, { status: 400 });
    }

    return new Response(
      JSON.stringify({
        ok: true,
        devices: tokens?.length ?? 0,
        title,
        message,
        deeplink,
        note: "Connect Firebase HTTP v1 credentials server-side to send real push notifications."
      }),
      { headers: { "Content-Type": "application/json" } },
    );
  } catch (e) {
    return new Response(String(e), { status: 500 });
  }
});
