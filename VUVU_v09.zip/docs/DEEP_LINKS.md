# Deep links VUVU v0.9

Formats prévus :

https://vuvu.app/video/123
https://vuvu.app/profile/UUID

L'application peut ouvrir :
- une vidéo précise ;
- un profil précis.

Pour production :
1. posséder un domaine, par exemple vuvu.app ;
2. configurer Android App Links ;
3. configurer iOS Universal Links ;
4. publier les fichiers d'association sur le domaine ;
5. tester l'ouverture depuis navigateur, SMS et notifications.
