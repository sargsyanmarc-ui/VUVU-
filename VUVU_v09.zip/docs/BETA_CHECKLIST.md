# VUVU v0.9 - Checklist bêta testeurs

## Fonctionnel
- inscription
- connexion
- publication vidéo
- lecture verticale
- pause / reprise
- likes
- commentaires
- partage par lien
- recherche utilisateur
- abonnements
- blocage
- signalement
- notifications internes
- deep links vidéo/profil
- suppression de compte
- modération admin

## Android
- Firebase configuré
- google-services.json présent
- APK release testé
- AAB généré
- signature release sauvegardée
- test sur au moins 2 appareils Android

## iPhone
- Firebase configuré
- GoogleService-Info.plist présent
- APNs configuré
- test sur vrai iPhone
- signing Xcode valide

## Sécurité
- RLS vérifiée
- service_role jamais dans l'app
- taille upload limitée
- modération testée
- compte admin séparé

## Bêta
- 5 à 20 testeurs
- formulaire de retours
- suivi crash / erreurs
- tests réseau lent
- tests vidéos verticales et horizontales
- tests déconnexion / reconnexion
